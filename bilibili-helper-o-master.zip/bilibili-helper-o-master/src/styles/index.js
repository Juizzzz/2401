/**
 * Author: Ruo
 * Create: 2018-07-28
 * Description: 引导文件，会被模板文件引用
 */

//export * from './globalInject';
export * from './var';
export * from './theme';
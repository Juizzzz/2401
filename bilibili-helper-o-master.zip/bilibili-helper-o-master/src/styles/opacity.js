/**
 * Author: Ruo
 * Create: 2018-07-28
 * Description:
 */

export const opacity = {
    'paper-blue-grey-900': '#263238',
    'dark-divider-opacity': '0.12',
    'dark-disabled-opacity': '0.38',
    'dark-secondary-opacity': '0.54',
    'dark-primary-opacity': '0.87',
    'light-divider-opacity': '0.12',
    'light-disabled-opacity': '0.3',
    'light-secondary-opacity': '0.7',
    'light-primary-opacity': '1.0',
};
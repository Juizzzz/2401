/**
 * Author: DrowsyFlesh
 * Create: 2019/3/1
 * Description:
 */

export {fetchImage} from './fetchImage';
export {fetchJSON} from './fetchJSON';
export {fetchPOST} from './fetchPOST';

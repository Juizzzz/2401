/**
 * Author: DrowsyFlesh
 * Create: 2018/12/2
 * Description:
 */
export default {
    getCurrentTask: 'https://api.live.bilibili.com/lottery/v1/SilverBox/getCurrentTask',
    getCaptcha: 'https://api.live.bilibili.com/lottery/v1/SilverBox/getCaptcha',
    getAward: 'https://api.live.bilibili.com/lottery/v1/SilverBox/getAward',
};
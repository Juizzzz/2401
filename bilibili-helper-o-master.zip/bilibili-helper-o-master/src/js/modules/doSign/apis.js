/**
 * Author: DrowsyFlesh
 * Create: 2018/12/2
 * Description:
 */
export default {
    doSign: 'https://api.live.bilibili.com/sign/doSign',
};
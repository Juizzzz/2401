/**
 * Author: DrowsyFlesh
 * Create: 2019/3/7
 * Description:
 */

export const bangumiFlvDownloadURL = 'https://api.bilibili.com/pgc/player/web/playurl';
export const normalFlvDownloadURL = 'https://api.bilibili.com/x/player/playurl';

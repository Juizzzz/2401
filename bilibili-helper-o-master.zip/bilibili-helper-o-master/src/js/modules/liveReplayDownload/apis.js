/**
 * Author: DrowsyFlesh
 * Create: 2020/1/4
 * Description:
 */
export default {
    getLiveRecord: 'https://api.live.bilibili.com/xlive/web-room/v1/record/getLiveRecordUrl',
}

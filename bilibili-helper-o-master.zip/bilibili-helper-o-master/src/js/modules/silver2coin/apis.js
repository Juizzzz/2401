/**
 * Author: DrowsyFlesh
 * Create: 2018/12/2
 * Description:
 */
export default {
    silver2coin: 'https://api.live.bilibili.com/pay/v1/Exchange/silver2coin',
}
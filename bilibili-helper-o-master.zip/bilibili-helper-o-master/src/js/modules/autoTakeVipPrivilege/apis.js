/**
 * Author: DrowsyFlesh
 * Create: 2018/12/2
 * Description:
 */
export default {
    getStatus: 'https://api.bilibili.com/x/vip/privilege/my',
    receive: 'https://api.bilibili.com/x/vip/privilege/receive',
};

/**
 * Author: DrowsyFlesh
 * Create: 2018/12/2
 * Description:
 */
export default {
    unread: 'https://api.bilibili.com/x/feed/unread/count?type=0',
    feed: 'https://api.bilibili.com/x/feed/pull?ps=1&type=0',
    dynamic_new: 'https://api.vc.bilibili.com/dynamic_svr/v1/dynamic_svr/dynamic_new',
    dynamic_num: 'https://api.vc.bilibili.com/dynamic_svr/v1/dynamic_svr/dynamic_num',
    dynamic_history: 'https://api.vc.bilibili.com/dynamic_svr/v1/dynamic_svr/dynamic_history',
};

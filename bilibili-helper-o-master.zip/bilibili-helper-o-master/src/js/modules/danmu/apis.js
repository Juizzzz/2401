/**
 * Author: DrowsyFlesh
 * Create: 2018/12/2
 * Description:
 */
export default {
    list: 'https://api.bilibili.com/x/v1/dm/list.so',
    historyList: 'https://api.bilibili.com/x/v2/dm/history',
    card: 'https://api.bilibili.com/x/web-interface/card',
    seg: 'https://api.bilibili.com/x/v2/dm/web/seg.so',
    view: 'https://api.bilibili.com/x/v2/dm/web/view',
}

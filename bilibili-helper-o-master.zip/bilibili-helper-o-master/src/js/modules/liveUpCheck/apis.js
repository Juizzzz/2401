/**
 * Author: DrowsyFlesh
 * Create: 2018/12/2
 * Description:
 */
export default {
    getList: 'https://api.live.bilibili.com/relation/v1/Feed/getList',
};

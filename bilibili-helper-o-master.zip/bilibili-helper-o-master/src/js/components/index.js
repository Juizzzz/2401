/**
 * Author: Ruo
 * Create: 2018-07-26
 * Description:
 */
export * from './common';
export * from './configPage';
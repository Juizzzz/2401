/**
 * Author: memorydream
 * Create: 2020/10/23
 * Description:
 */
 
 import {UIManager} from "Libs/UIManager";

 new UIManager('home');
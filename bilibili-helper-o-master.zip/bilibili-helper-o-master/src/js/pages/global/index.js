/**
 * Author: Cotch22
 * Create: 2020/8/4
 * Description: 全局
 */
import {UIManager} from 'Libs/UIManager';

new UIManager('global');
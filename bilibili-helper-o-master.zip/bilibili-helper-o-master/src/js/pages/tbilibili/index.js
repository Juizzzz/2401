/**
 * Author: DrowsyFlesh
 * Create: 2019/3/21
 * Description:
 */
import {UIManager} from 'Libs/UIManager';

new UIManager('tbilibili');

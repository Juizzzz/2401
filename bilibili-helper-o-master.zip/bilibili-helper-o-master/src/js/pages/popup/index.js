/**
 * Author: Ruo
 * Create: 2018-06-12
 * Description: 扩展菜单脚本
 */
import {UIManager} from 'Libs/UIManager';

new UIManager('popup');
